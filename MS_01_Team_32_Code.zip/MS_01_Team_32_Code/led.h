#ifndef LED_H
#define LED_H

// Updated GPIO pins for the LEDs
#define RED_LED_PIN 19
#define GREEN_LED_PIN 20
#define BLUE_LED_PIN 21

// Function prototypes
void led_init();            // Initialize LED pins
void turn_off_leds();        // Turn off all LEDs
void led_sequence();         // Control the LED sequence

#endif // LED_H
