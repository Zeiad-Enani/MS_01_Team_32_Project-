#include <stdio.h>
#include "pico/stdlib.h"
#include "led.h"

int main() {

    stdio_init_all();  
    led_init();         // Initialize LEDs

    // Run the 10 sec loop infinitely
    while (1) {
        led_sequence(); 
    }

    return 0;
}
