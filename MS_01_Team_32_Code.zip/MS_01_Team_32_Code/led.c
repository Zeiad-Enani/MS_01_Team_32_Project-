#include "led.h"
#include "pico/stdlib.h"

// Initialize the GPIO pins for the LEDs
void led_init() {
    gpio_init(RED_LED_PIN);
    gpio_set_dir(RED_LED_PIN, GPIO_OUT);

    gpio_init(GREEN_LED_PIN);
    gpio_set_dir(GREEN_LED_PIN, GPIO_OUT);

    gpio_init(BLUE_LED_PIN);
    gpio_set_dir(BLUE_LED_PIN, GPIO_OUT);
}

// Turn off all LEDs
void turn_off_leds() {
    gpio_put(RED_LED_PIN, 0);
    gpio_put(GREEN_LED_PIN, 0);
    gpio_put(BLUE_LED_PIN, 1);  // Blue LED uses negative logic
}

// Perform the LED sequence
void led_sequence() {

    // All LEDs off for 5 seconds
    turn_off_leds();  
    sleep_ms(5000);

    // Red LED ON for 1 second
    gpio_put(RED_LED_PIN, 1);  
    sleep_ms(1000);
    gpio_put(RED_LED_PIN, 0);  

    // Green LED ON for 1 second
    gpio_put(GREEN_LED_PIN, 1);  
    sleep_ms(1000);
    gpio_put(GREEN_LED_PIN, 0);

    // Blue LED ON for 1 second (negative logic)
    gpio_put(BLUE_LED_PIN, 0);  
    sleep_ms(1000);
    gpio_put(BLUE_LED_PIN, 1);

    // All LEDs ON for 2 seconds
    gpio_put(RED_LED_PIN, 1);
    gpio_put(GREEN_LED_PIN, 1);
    gpio_put(BLUE_LED_PIN, 0);  
    sleep_ms(2000);

    turn_off_leds();
}
